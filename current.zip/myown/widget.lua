return {
	taglist = require("myown.widget.taglist"),
}
