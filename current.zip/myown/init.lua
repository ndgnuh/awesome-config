return {
	widget = require("myown.widget"),
	client = require("myown.client"),
	shape = require("myown.shape"),
	menu = require("myown.menu"),
}
